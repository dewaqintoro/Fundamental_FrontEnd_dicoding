import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import "./styles/style.css";
import "./script/component/navbar.js";
import "./script/component/header.js";
import "./script/component/footer.js";
import "./script/component/toTop.js";
import "./script/data/lirik.js";