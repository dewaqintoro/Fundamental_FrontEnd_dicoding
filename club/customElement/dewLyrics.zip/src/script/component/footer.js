function sikel() {
    document.getElementById("sikel").innerHTML = `<p class="flow-text">DevDew &copy; Copyright 2020</p>`;
}

sikel()